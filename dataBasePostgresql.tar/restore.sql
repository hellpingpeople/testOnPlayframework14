--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.booking DROP CONSTRAINT fk_qyoou1kosk9nph269okbrtjii;
ALTER TABLE ONLY public.booking DROP CONSTRAINT fk_8u559gulj0bgoclx8064ngetf;
ALTER TABLE ONLY public.persona DROP CONSTRAINT fk_5593cwc1yebqtwwlev6anm3n4;
ALTER TABLE ONLY public.persona DROP CONSTRAINT persona_pkey;
ALTER TABLE ONLY public.customer DROP CONSTRAINT customer_pkey;
ALTER TABLE ONLY public.booking DROP CONSTRAINT booking_pkey;
ALTER TABLE ONLY public.auto DROP CONSTRAINT auto_pkey;
DROP TABLE public.persona;
DROP SEQUENCE public.hibernate_sequence;
DROP TABLE public.customer;
DROP TABLE public.booking;
DROP TABLE public.auto;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auto; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auto (
    id bigint NOT NULL,
    body character varying(255),
    cel integer,
    color character varying(255),
    modelname character varying(255),
    passengercapacity character varying(255),
    power numeric(6,2),
    registerdate timestamp without time zone,
    registernumber character varying(255)
);


ALTER TABLE auto OWNER TO postgres;

--
-- Name: booking; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE booking (
    id bigint NOT NULL,
    persona_id bigint,
    user_id bigint
);


ALTER TABLE booking OWNER TO postgres;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE customer (
    id bigint NOT NULL,
    name character varying(255),
    password character varying(255),
    username character varying(255)
);


ALTER TABLE customer OWNER TO postgres;

--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hibernate_sequence OWNER TO postgres;

--
-- Name: persona; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE persona (
    id bigint NOT NULL,
    burnyear timestamp without time zone,
    city character varying(255),
    country character varying(255),
    firstname character varying(255),
    lastname character varying(255),
    patronymic character varying(255),
    price numeric(6,2),
    sex character varying(255),
    auto_id bigint
);


ALTER TABLE persona OWNER TO postgres;

--
-- Data for Name: auto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auto (id, body, cel, color, modelname, passengercapacity, power, registerdate, registernumber) FROM stdin;
\.
COPY auto (id, body, cel, color, modelname, passengercapacity, power, registerdate, registernumber) FROM '$$PATH$$/2022.dat';

--
-- Data for Name: booking; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY booking (id, persona_id, user_id) FROM stdin;
\.
COPY booking (id, persona_id, user_id) FROM '$$PATH$$/2023.dat';

--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY customer (id, name, password, username) FROM stdin;
\.
COPY customer (id, name, password, username) FROM '$$PATH$$/2024.dat';

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('hibernate_sequence', 23, true);


--
-- Data for Name: persona; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY persona (id, burnyear, city, country, firstname, lastname, patronymic, price, sex, auto_id) FROM stdin;
\.
COPY persona (id, burnyear, city, country, firstname, lastname, patronymic, price, sex, auto_id) FROM '$$PATH$$/2026.dat';

--
-- Name: auto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auto
    ADD CONSTRAINT auto_pkey PRIMARY KEY (id);


--
-- Name: booking_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY booking
    ADD CONSTRAINT booking_pkey PRIMARY KEY (id);


--
-- Name: customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: persona_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY persona
    ADD CONSTRAINT persona_pkey PRIMARY KEY (id);


--
-- Name: fk_5593cwc1yebqtwwlev6anm3n4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY persona
    ADD CONSTRAINT fk_5593cwc1yebqtwwlev6anm3n4 FOREIGN KEY (auto_id) REFERENCES auto(id);


--
-- Name: fk_8u559gulj0bgoclx8064ngetf; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY booking
    ADD CONSTRAINT fk_8u559gulj0bgoclx8064ngetf FOREIGN KEY (user_id) REFERENCES customer(id);


--
-- Name: fk_qyoou1kosk9nph269okbrtjii; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY booking
    ADD CONSTRAINT fk_qyoou1kosk9nph269okbrtjii FOREIGN KEY (persona_id) REFERENCES persona(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

